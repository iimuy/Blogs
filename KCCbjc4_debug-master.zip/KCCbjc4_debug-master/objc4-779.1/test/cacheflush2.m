#include "cacheflush.h"

@implementation TestRoot (Category2)
+(int)classMethod { return 2; }
-(int)instanceMethod { return 2; }
@end
